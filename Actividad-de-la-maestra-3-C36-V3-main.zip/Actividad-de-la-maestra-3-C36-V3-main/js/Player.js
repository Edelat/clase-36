class Player {
  constructor() {}
}
